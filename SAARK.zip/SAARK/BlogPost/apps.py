from django.apps import AppConfig


class BlogpostConfig(AppConfig):
    name = 'BlogPost'
