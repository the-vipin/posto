from django.apps import AppConfig


class BloggersConfig(AppConfig):
    name = 'Bloggers'
